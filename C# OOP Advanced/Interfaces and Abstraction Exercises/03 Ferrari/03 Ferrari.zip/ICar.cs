﻿namespace Ferrari
{
    public interface ICar
    {
        string PushBrakes();
        string PushGaz();
    }
}
